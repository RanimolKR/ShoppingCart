function billing1() {
	window.open("home.html","_self");
}

function billing2() {
	window.open("payment.html","_self");
}