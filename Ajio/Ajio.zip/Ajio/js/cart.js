function cart1() {
	window.open("home.html","_self");
}

function cart2() {
	window.open("billing.html","_self");
}