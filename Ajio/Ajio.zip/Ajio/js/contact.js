function contact1() {
	window.open("home.html","_self");
}
function contact2() {
	window.open("cart.html","_self");
}