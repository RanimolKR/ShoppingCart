function detail1() {
	window.open("home.html","_self");
}

function detail2() {
	window.open("cart.html","_self");
}

function detail3() {
	window.open("cart.html","_self");
}
