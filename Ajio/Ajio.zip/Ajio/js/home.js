function home1() {
	window.open("home.html","_self");
}

function home2() {
	window.open("cart.html","_self");
}
