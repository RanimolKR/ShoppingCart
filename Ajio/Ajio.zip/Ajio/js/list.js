function list1() {
	window.open("home.html","_self");
}
function list2() {
	window.open("cart.html","_self");
}

